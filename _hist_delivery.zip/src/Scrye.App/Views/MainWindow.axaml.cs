using Avalonia.Controls;
using Avalonia.Input;
using Scrye.App.ViewModels;

namespace Scrye.App.Views;

public partial class MainWindow : Window
{
    public MainWindow() => InitializeComponent();

    private void OnInputKeyDown(object? sender, KeyEventArgs e)
    {
        if (sender is not TextBox box || box.DataContext is not WorldViewModel vm) return;

        switch (e.Key)
        {
            case Key.Enter:
                vm.SubmitCommand.Execute(null);
                e.Handled = true;
                break;
            case Key.Up:                                  // recall previous command
                Recall(box, vm.HistoryPrevious(box.Text ?? ""));
                e.Handled = true;
                break;
            case Key.Down:                                // recall next / restore draft
                Recall(box, vm.HistoryNext());
                e.Handled = true;
                break;
            case Key.Escape:                              // clear the input
                box.Text = "";
                box.CaretIndex = 0;
                e.Handled = true;
                break;
        }
    }

    private static void Recall(TextBox box, string? text)
    {
        if (text is null) return;
        box.Text = text;
        box.CaretIndex = text.Length;   // caret to end
    }
}
